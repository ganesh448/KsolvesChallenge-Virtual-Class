package jds.virtualclassroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualclassroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
