package repositories;

import java.util.List;

import standardclass.Models.Comment;

public interface CommentRepository {

	List<Comment> findByLectureId(Long lectureId);

	Comment save(Comment comment);

}
