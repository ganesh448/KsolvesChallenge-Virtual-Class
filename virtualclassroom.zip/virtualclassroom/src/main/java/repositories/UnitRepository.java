package repositories;

import java.util.List;

import standardclass.Models.Unit;

public class UnitRepository {

	public List<Unit> findByClassEntityId(Long classId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Unit> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Unit save(Unit unit) {
		// TODO Auto-generated method stub
		return null;
	}

}
