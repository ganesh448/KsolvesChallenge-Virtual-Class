package jds.virtualclassroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualclassroomApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualclassroomApplication.class, args);
		System.out.println("Ready TO Launch");
	
		
	}
	
	

}
